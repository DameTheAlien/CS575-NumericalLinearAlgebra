Homework 4
Damian Franco
CS-575

This directory contains
  -  HW5Code_DamianFranco.ipynb
  -  HW5Code_DamianFranco.py

To run the Jupyter Notebook, please open up your favorite Jupyter workshop/IDE and run by pressing 'Run All'.

To run the Python code, please compile it with python3 in the command line of your system.

Each file has a single part that utilizes NumPy library functions to solve the normal equations for problem 2.