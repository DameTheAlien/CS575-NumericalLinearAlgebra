Homework 7
Damian Franco
CS-575

This directory contains
  -  HW7Code_DamianFranco.ipynb
  -  HW7Code_DamianFranco.py

To run the Jupyter Notebook, please open up your favorite Jupyter workshop/IDE and run by pressing 'Run All'.

To run the Python code, please compile it with python3 in the command line of your system.

This program implements two versions of the power iteration method to predicting the largest eigenvalue and its associated eigenvector. 
The first implementation is a naive version with no normalization techniques while the second implemenation utilizes normalization 
techniques to properly compute the eigenvectors associated with the largest eigenvalues predictions.