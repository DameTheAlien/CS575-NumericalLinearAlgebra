Homework 3
Damian Franco
CS-575

This directory contains
  -  HW3Code_DamianFranco.ipynb
  -  HW3Code_DamianFranco.py

To run the Jupyter Notebook, please open up your favorite Jupyter workshop/IDE and run by pressing 'Run All'.

To run the Python code, please compile it with python3 in the command line of your system.

Each file has one main function/definitions call which is the GE function which internally calls the forward and 
backward substitution functions.