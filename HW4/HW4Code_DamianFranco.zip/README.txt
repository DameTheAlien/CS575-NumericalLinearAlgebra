Homework 4
Damian Franco
CS-575

This directory contains
  -  HW4Code_DamianFranco.ipynb
  -  HW4Code_DamianFranco.py

To run the Jupyter Notebook, please open up your favorite Jupyter workshop/IDE and run by pressing 'Run All'.

To run the Python code, please compile it with python3 in the command line of your system.

Each file has two parts, one is for the question 4 involving hilbert matrix systems and ill-conditioning 
and the other is for testing the loss of precision in question 6.