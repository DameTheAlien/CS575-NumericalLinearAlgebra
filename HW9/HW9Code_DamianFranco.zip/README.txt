Homework 9
Damian Franco
CS-575

This directory contains
  -  HW9Code_DamianFranco.ipynb
  -  HW9Code_DamianFranco.py

To run the Jupyter Notebook, please open up your favorite Jupyter workshop/IDE and run by pressing 'Run All'.

To run the Python code, please compile it with python3 in the command line of your system.

This program has two parts to the code. The first is setting up a matrix A and finding the iteration matrix 
and properties of the matrix to determine if the matrix will converge using Gauss-Seidel's algorithm. 
The next section (Question 3) is an implementation of Jacobi's and Gauss-Seidels algorithms to solve a linear 
system Ax = b with some examples and tables of my findings.