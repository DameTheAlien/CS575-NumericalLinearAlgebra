Homework 6
Damian Franco
CS-575

This directory contains
  -  HW6Code_DamianFranco.ipynb
  -  HW6Code_DamianFranco.py

To run the Jupyter Notebook, please open up your favorite Jupyter workshop/IDE and run by pressing 'Run All'.

To run the Python code, please compile it with python3 in the command line of your system.

This program implements three version of QR decomposition. The Gram-Schmidt approach is used with Classical Gram-Schmidt, 
Modified Gram-Schmidt version 1 and Modified Gram-Schmidt version 2. Each section below has the function for its respective 
approach. Testing is done with a small 3x2 matrix and with a large matrix with linearly dependent columns.