Homework 1
Damian Franco
CS-575

This directory contains
  -  HW1_DamianFranco.ipynb
  -  HW1_DamianFranco.py

To run the Jupyter Notebook, please open up your favorite Jupyter workshop/IDE and run by pressing 'Run All'.

To run the Python code, please compile it with python3 in the command line of your system.

Each file has two main function/definitions calls. The first is for the matrix-vector multiplication and the next is for matrix-matrix multiplication.